import React from "react";
import '../CSS/HorizontalBar.css'

const HorizontalBar = () =>
{
    return(

        <center>
            <div class="horizontalBar">
                <div class="hBar" style={{width:'50%'}}>{' 50%'}</div>
            </div>
        
        </center>
    )

}
export default HorizontalBar;