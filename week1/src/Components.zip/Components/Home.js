import React from "react"

const Home = (props) =>{
    let fn = props.name;
    let sn = props.surname;
    return(
        
        <center>
            <h1>Welcome {fn} {sn}</h1>
        </center>
    );
};

export default Home